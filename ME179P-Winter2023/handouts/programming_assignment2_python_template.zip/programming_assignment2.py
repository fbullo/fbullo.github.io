# Copyright 2021 Francesco Seccamonte

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# Template file for the assignment.
#
#
# Author:         Francesco Seccamonte, 2021
#
# YOU MUST USE THIS FILE AND THE API HEREIN.
# DO NOT MODIFY HOW FUNCTIONS AND METHODS ARE DEFINED,
# SIMPLY FILL WHERE TODOs ARE.
#
# YOU NEED TO UPLOAD THIS FILE AS PART OF YOUR SUBMISSION


# Place your imports here as needed
import numpy as np

# Hint: the exercise asks you to give some kind of error
# in case of wrong inputs: you should do so by raising an Exception.

# Hint n.2: you may want to reuse the functions you wrote for
# programming assignment 1. You can import them by doing:
# from programming_assignment1 import *
# Remember to include that file as part of your submission!

def inpolygon(q, P):
    """
    :param q: a point in 2D specified as a numpy array
    :param P: a polygon with n vertices specified as an nx2 numpy array
    :return: 1 if the point q is inside the polygon P, 0 else.
    """

    from matplotlib import path

    p = path.Path(P);
    return p.contains_point(q);

def computeDistancePointToPolygon(q, P):
    """
    :param q: a point in 2D specified as a numpy array
    :param P: a polygon with n vertices specified as an nx2 numpy array
    :return: a tuple (d,v,idx) containing the distance from the point to
                the polygon, whether the distance is wrt a vertex (v=1) or not,
                the index idx within the polygonal list of
                either the vertex or segment which is closest to q.
                The first segment is considered to be the one
                between the first and second vertices.
    """
    
    # Write your code here

    return d, v, idx;


def computeTangentVectorToPolygon(q, P):
    """
    :param q: a point in 2D specified as a numpy array
    :param P: a polygon with n vertices specified as an nx2 numpy array
    :return: the two-dimensional unit vector t (numpy array) tangent
                to the polygon P for a robot at q.
    """

    # Write your code here

    return t;

    