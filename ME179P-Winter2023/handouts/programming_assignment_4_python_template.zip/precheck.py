# Copyright 2021 Francesco Seccamonte

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# Programming assignment 4 - Check the functions run

from programming_assignment4 import *

if __name__ == '__main__':
	
	Gs = computeGridSukharev(4);
	# should be equal to 0.25 	0.25 	0.75 	0.75
	#					 0.25 	0.75  	0.25  	0.75
	# a permutation of the columns is also fine

	Gr = computeGridRandom(4);

	Gh = computeGridHalton(4,2,3);
	# should be equal to 0.5 	0.25 	0.75 	0.125
	#					 0.3333 0.6667  0.1111  0.4444
	