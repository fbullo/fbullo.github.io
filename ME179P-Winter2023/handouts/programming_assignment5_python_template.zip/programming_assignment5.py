# Copyright 2021 Francesco Seccamonte

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# Template file for programming assignment 5.
#
# Original author: Patrick Therrien, 2015
# Refactor:\t\tFrancesco Seccamonte, 2021
#
# YOU MUST USE THIS FILE AND THE API HEREIN.
# DO NOT MODIFY HOW FUNCTIONS AND METHODS ARE DEFINED,
# SIMPLY FILL WHERE TODOs ARE.
#
# YOU NEED TO UPLOAD THIS FILE AS PART OF YOUR SUBMISSION


# Place your imports here as needed
import numpy as np

def isPointInConvexPolygon(q,P):
	"""
	:param q: a point in 2D specified as a numpy array
	:param P: a polygon with n vertices specified as an nx2 numpy array
			  # NOTE: our convention is that a polygon is
              # represented by a list of vertices in
              # counterclockwise order
	:return: True if q is in (or on the boundary of) P, False else.
	"""

	  # Write your code here

    return isinP;


def doTwoSegmentsIntersect(p1,p2,p3,p4):
    """
    :param p1: first vertex of the first segment
    :param p2: second vertex of the first segment
    :param p3: first vertex of the second segment
    :param p4: second vertex of the second segment
    :return: a tuple (intersect, q) containing whether the
             two segments intersect (True or False), and the
             intersection point q (point [nan, nan] if they don't).
    """

    # Write your code here

    return dotheyintersect, pofint;


def doTwoConvexPolygonsIntersect(P1,P2):
    """
    :param P1: a polygon with m vertices specified as an nx2 numpy array
    :param P2: a polygon with n vertices specified as an nx2 numpy array
              # NOTE: our convention is that a polygon is
              # represented by a list of vertices in
              # counterclockwise order
    :return: True if P1 and P2 intersect, False else.
    """

    # Write your code here

    return dotheyintersect;

