# Copyright 2021 Francesco Seccamonte

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# Programming assignment 5 - Check the functions run

from programming_assignment5 import *
import numpy as np

if __name__ == '__main__':
    
    q = np.array([1, 1]);

    P1 = np.array([[0, 0],
            [2, 0],
            [2, 2],
            [0, 2]]);

    inp = isPointInConvexPolygon(q, P1);
    # should return True

    p1 = np.array([1, 1]);
    p2 = np.array([3, 1]);
    p3 = np.array([2, 0.5]);
    p4 = np.array([2, 1.5]);

    intersect, pofint = doTwoSegmentsIntersect(p1,p2,p3,p4);
    # should return True, [2, 1]

    P2 = np.array([[1, 1],
            [3, 1],
            [3, 3],
            [1, 3]]);

    intersect = doTwoConvexPolygonsIntersect(P1, P2);
    # should return True
