# Copyright 2021 Francesco Seccamonte

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# Template file for the assignment.
#
# Original author:  Patrick Therrien, 2015
# Refactor:         Francesco Seccamonte, 2021
#
# YOU MUST USE THIS FILE AND THE API HEREIN.
# DO NOT MODIFY HOW FUNCTIONS AND METHODS ARE DEFINED,
# SIMPLY FILL WHERE TODOs ARE.
#
# YOU NEED TO UPLOAD THIS FILE AS PART OF YOUR SUBMISSION


# Place your imports here as needed
import numpy as np

# Hint: the exercise asks you to give some kind of error
# in case of wrong inputs: you should do so by raising an Exception.

def computeLineThroughTwoPoints(p1, p2):
    """
    :param p1: a point in 2D specified as a numpy array
    :param p2: a point in 2D specified as a numpy array
    :return: a tuple (a,b,c) containing the coefficients of the line ax+ by = c 
    passing through p1 and p2
    """
    
    # Write your code here

    return a, b, c;


def computeDistancePointToLine(q, p1, p2):
    """
    :param q: the test point as a numpy array
    :param p1: the first point defining the line
    :param p2: the second point defining the line
    :return: the distance from the test point q to the line defined by p1 and p2
    """

    # Write your code here

    return d;


def computeDistancePointToSegment(q, p1, p2):
    """
    :param q: the test point as a numpy array
    :param p1: the first endpoint of the line segment
    :param p2: the second endpoint of the line segment
    :return: the distance d from the test point q to the line segment
            with endpoints p1 and p2
            w, with w=0 if the segment point closest to q is strictly
            inside the segment, w=1 if the closest point is p1, and
            w= 2 if the closest point is p2.
    """
    
    # Write your code here

    return d, w;
    