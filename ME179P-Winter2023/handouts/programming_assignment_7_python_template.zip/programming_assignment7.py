# Copyright 2021 Francesco Seccamonte

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# Template file for programming assignment 5.
#
# Original author: Patrick Therrien, 2015
# Refactor:\t\tFrancesco Seccamonte, 2021
#
# YOU MUST USE THIS FILE AND THE API HEREIN.
# DO NOT MODIFY HOW FUNCTIONS AND METHODS ARE DEFINED,
# SIMPLY FILL WHERE TODOs ARE.
#
# YOU NEED TO UPLOAD THIS FILE AS PART OF YOUR SUBMISSION


# Place your imports here as needed
import numpy as np

def computeRMfromAA(theta, n):
    """
    :param theta: an angle in radians
    :param n: a unit-length vector specified as a numpy array
    :return: Corresponding rotation matrix as a numpy ndarray
    """

    # Write your code here

    return R;

def computeAAfromRM(R):
    """
    :param R: A rotation matrix as a numpy ndarray (3x3)
    :return: A tuple [theta, n] containing the rotation angle
             theta (scalar, in radians) and the axis of rotation
             n (numpy array)
    """

    # Write your code here

    return theta, n;
