# Copyright 2021 Francesco Seccamonte

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# Template file for programming assignment 3.
#
# 
# Author:        Francesco Seccamonte, 2021
#
# YOU MUST USE THIS FILE AND THE API HEREIN.
# DO NOT MODIFY HOW FUNCTIONS AND METHODS ARE DEFINED,
# SIMPLY FILL WHERE TODOs ARE.
#
# YOU NEED TO UPLOAD THIS FILE AS PART OF YOUR SUBMISSION


# Place your imports here as needed

def computeBFSTree(adjTable,start):
    """Compute a BFS tree for the graph described by
    its adjacency Table tableAdjTable and a start node
    start.

    :param adjTable: the adjacency table of a graph,
                     specified as a list of lists
                     NOTE: Adjtable is 1-indexed,
                     i.e., nodes are 1,2,...,N
    :param start: a node in the graph, specified as an index
                  in the adjacency table
    :return: a list containing all the parents of the nodes
             in the graph.
    """

    # Write your code here
    
    return parent;


def computeBFSPath(adjTable,start,goal):
    """Compute a path from start to goal using
    BFS.

    :param adjTable: the adjacency table of a graph,
                     specified as a list of lists
                     NOTE: Adjtable is 1-indexed,
                     i.e., nodes are 1,2,...,N
    :param start: a node in the graph, specified as an index
                  in the adjacency table
    :param goal: a node in the graph, specified as an index
                  in the adjacency table
    :return: a list containing the l indices
             that make up the path.
    """

    # Write your code here
       
    return path;


def computeDistanceOnCircle(theta1, theta2):
    """Compute the distance between two angles on
    a circle.

    :param theta1: first angle (in radians)
    :param theta2: second angle (in radians)
    :return: distance between theta1 and theta2.
    """

    # Write your code here

    return d;


def computeDistanceOnTorus(alpha1, alpha2, beta1, beta2):
    """Compute the distance between two points on the
    torus angles.

    :param alpha1: first component of angle1 (in radians)
    :param alpha2: first component of angle2 (in radians)
    :param beta1: second component of angle1 (in radians)
    :param beta2: second component of angle2 (in radians)
    :return: distance between angle1 and angle2.
    """
    
    # Write your code here
    
    return d;

