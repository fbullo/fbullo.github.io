# Copyright 2021 Francesco Seccamonte

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# Programming assignment 3 - Check the functions run

from programming_assignment3 import *
import numpy as np

if __name__ == '__main__':
	############# PART 1 #################

	# NOTE: the AdjTable is 1-indexed, i.e., nodes are 1,2,...,N
	AdjTable = [[2], [1, 3, 4], [2], [2, 5], [4]];
	start = 1;
	parents = computeBFSTree(AdjTable, start);
	# parents should be equal to [-1, 1, 2, 2, 4]

	goal = 5;
	pathidx = computeBFSPath(AdjTable, start, goal);
	# pathidx should be equal to [1, 2, 4, 5]

	############# PART 2 #################

	theta1 = np.pi/6;
	theta2 = np.pi/3;

	dc = computeDistanceOnCircle(theta1, theta2);
	# dc should be equal to pi/6 \approx 0.5235987755982988

	beta1 = np.pi/4;
	beta2 = -3/4*np.pi;

	dt = computeDistanceOnTorus(theta1, theta2, beta1, beta2);
	# dt should be approx equal to 3.184927013119358