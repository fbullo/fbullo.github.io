# Copyright 2021 Francesco Seccamonte

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# Programming project 1 - Check the functions run

from programming_project1 import *
import numpy as np
import matplotlib.pyplot as plt

if __name__ == '__main__':

    start = np.array([0.0, 0.0]);
    goal = np.array([3.0, 3.0]);
    goalbase = np.array([1.0, -3.0]);
    stepsize = 0.1;
    
    # NOTE: our convention is that a polygon is
    # represented by a list of vertices in
    # counterclockwise order
    P = np.array([[1, 1],
        [3, 1],
        [2, 2],
        [2, 3]]);
    obstacleList = [P];
    obstaclesList_plot = [P.tolist()];
    
    pathbase, closestPoly, success = BugBase(start,goalbase,obstacleList,stepsize);
    path = computeBug1(start, goal, obstacleList, stepsize);
    
    ###### PLOTTING #######
    plt.close('all');

    plt.plot(start[0],start[1],'o', label='Start point');
    plt.plot(goalbase[0],goalbase[1],'*', label='Goal point (Bugbase)');
    plt.plot(goal[0],goal[1],'+', label='Goal point (Bug1)');
    
    Xb,Yb=map(list,zip(*pathbase));
    X,Y=map(list,zip(*path));
    plt.plot(Xb,Yb, label='BugBase path');
    plt.plot(X,Y, label='Bug1 path');
    
    for i in range(len(obstaclesList_plot)):
        obstaclesList_plot[i].append(obstaclesList_plot[i][0]);
        X,Y=map(list,zip(*obstaclesList_plot[i]));
        plt.plot(X,Y, 'y');
    
    plt.legend();
    plt.show();
