# Copyright 2021 Francesco Seccamonte

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# Template file for programming project 1.
#
#
# Author:         Francesco Seccamonte, 2021
#
# YOU MUST USE THIS FILE AND THE API HEREIN.
# DO NOT MODIFY HOW FUNCTIONS AND METHODS ARE DEFINED,
# SIMPLY FILL WHERE TODOs ARE.
#
# YOU NEED TO UPLOAD THIS FILE AS PART OF YOUR SUBMISSION


# Place your imports here as needed
import numpy as np

# Hint: you may want to reuse the functions you wrote for
# programming assignments 1 and 2. You can import them by doing:
# from programming_assignment1 import *
# from programming_assignment2 import *
# Remember to include that file as part of your submission!

# Hint 2: it is strongly recommended to insert the functionalities
# needed in separate auxiliary functions, to improve debugging
# and readability, and to embrace the extremely useful DRY
# paradigm (=Don't Repeat Yourself)


def BugBase(start,goal,obstacleList,stepsize):
    """Implementation of the BugBase algorithm.

    :param start: a point in 2D specified as a numpy array
    :param goal: a point in 2D specified as a numpy array
    :param obstacleList: a list containing all the obstacles
                         (represented by polygons) in the environment.
                         # NOTE: our convention is that a polygon is
                         # represented by a list of vertices in
                         # counterclockwise order
    :param stepsize: a positive real number
    :return: a tuple (path, polygon index, success): path is a
             list containing the l 2D points
             that make up the path.
             polygon index is the index in the obstacleList
             corresponding to the polygon hit in case of returning a
             partial path (-1 if start-goal path returned).
             success is a boolean indicating whether the algorithm
             reached the goal or not.
    """
    
    # Write your code here

    return path, idx, success;


def computeBug1(start,goal,obstacleList,stepsize):
    """Implementation of the Bug1 algorithm.

    :param start: a point in 2D specified as a numpy array
    :param goal: a point in 2D specified as a numpy array
    :param obstacleList: a list containing all the obstacles
                         (represented by polygons) in the environment.
                         # NOTE: our convention is that a polygon is
                         # represented by a list of vertices in
                         # counterclockwise order
    :param stepsize: a positive real number
    :return: a list containing the l 2D points
             that make up the path.
    """

    # Write your code here

    return path;

